package day01;

public class 변수 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10;
		int b = 20;
		System.out.println(a);
		System.out.println(b);

		int c = a + b;
		System.out.println(c);

		int d = a;
		System.out.println(d);

		a = 20;
		b = 30;
		System.out.println(a + b);

		c = 100;
		System.out.println(c);
		c = a + b;
		System.out.println(c);

		int z = 10;
		System.out.println(z);
		

	}

}
