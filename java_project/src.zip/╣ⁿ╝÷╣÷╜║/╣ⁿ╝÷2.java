package 범수버스;

import java.util.Scanner;

public class 범수2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		boolean run = true;
		int balance = 0; 
		
		while(run) {
			System.out.println("======자판기======" + "잔액 : " + balance + "원");
			System.out.println("1.콜라(1000원) 2.사이다(1200원) 3.우유(1500원) 4.충전 0.종료");
			System.out.print("메뉴선택 : ");
		}
			
			
	}

}



















