package day08;

public class Game {

	public static void main(String[] args) {
		

	}

}
